#pragma once 
// permet au fichier .hde n'�tre inclue qu'une seule fois

void hello_world();
void print_version();