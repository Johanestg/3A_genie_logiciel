// options and settings exported to source code

#define HelloProj_VERSION_MAJOR 1
#define HelloProj_VERSION_MINOR 0
